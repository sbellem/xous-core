# Secure Rust Dependency Packaging for Guix Builds

## A Comprehensive Guide for Supply Chain Security

**Target Project:** xous-core  
**Build System:** GNU Guix (New Rust Packaging Model - Merged 2025)  
**Build Tool:** cargo xtask  
**Threat Model:** Software Supply Chain Attacks

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [The New Guix Rust Packaging Model](#the-new-guix-rust-packaging-model)
3. [Git Dependencies: The Key Insight](#git-dependencies-the-key-insight)
4. [Threat Model](#threat-model)
5. [Security Architecture](#security-architecture)
6. [Trust Anchors](#trust-anchors)
7. [Implementation for xous-core](#implementation-for-xous-core)
8. [Handling cargo xtask](#handling-cargo-xtask)
9. [Guix Integration](#guix-integration)
10. [Verification Procedures](#verification-procedures)
11. [Workflow](#workflow)
12. [Path to Fully Bootstrapped Rust](#path-to-fully-bootstrapped-rust)
13. [Limitations and Known Gaps](#limitations-and-known-gaps)
14. [Appendix: Tools and Scripts](#appendix-tools-and-scripts)

---

## Executive Summary

GNU Guix has merged a **new Rust packaging model** (2025) that fundamentally changes how Rust applications are packaged.

### Critical Clarification: Git Dependencies ARE Supported

| Component | Git Dependency Support | Notes |
|-----------|------------------------|-------|
| `guix import crate --lockfile` | ❌ No | Tool limitation - skips git deps |
| `rust-crates.scm` | ❌ No | Only auto-imported crates.io sources |
| **`rust-sources.scm`** | ✅ **Yes** | Manual definitions for git deps |
| `cargo-inputs` procedure | ✅ Yes | Pulls from **both** modules |
| `cargo-build-system` | ✅ Yes | Handles any origin type |

**The importer tool has limitations, but the underlying model fully supports git dependencies when manually defined in `rust-sources.scm`.**

This new model:

- Uses `Cargo.lock` as the source of truth for dependencies
- Stores crates as **sources** (origins), not packages
- Deprecates `#:cargo-inputs` and `#:cargo-development-inputs` (removal after Dec 31, 2026)
- Provides `cargo-inputs` procedure for dependency lookup
- Hides Rust libraries from the user interface

This document describes how to leverage the new model while maintaining supply chain security for high-assurance projects like xous-core.

### Key Security Measures

| Layer | Mechanism | Purpose |
|-------|-----------|---------|
| **Audit** | cargo-vet | Human review attestations |
| **Verify** | Software Heritage | Independent third-party verification |
| **Lock** | Cargo.lock + Guix lockfile importer | Deterministic dependency resolution |
| **Isolate** | Guix sandboxed builds | Network-free compilation |
| **Document** | Provenance records | Complete audit trail |

---

## The New Guix Rust Packaging Model

### Background

The previous Guix approach mapped one Rust crate to one Guix package. This caused problems:

- Thousands of library packages cluttered the user interface
- Built artifacts couldn't be reused (Rust compiles everything together)
- `#:cargo-inputs` was inconsistent with standard Guix inputs
- Circular dependencies required special handling

### What Changed

```
┌─────────────────────────────────────────────────────────────────┐
│                    OLD MODEL (Deprecated)                        │
│                                                                  │
│   (arguments                                                    │
│    (list #:cargo-inputs                                         │
│          (list rust-serde-1                                     │
│                rust-tokio-1)))                                  │
│                                                                  │
│   - Each crate = Guix package                                   │
│   - Recursive import from crates.io                             │
│   - Packages visible to users                                   │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                    NEW MODEL (Current)                           │
│                                                                  │
│   (inputs (cargo-inputs 'my-package))                           │
│                                                                  │
│   - Each crate = Guix origin (source only)                      │
│   - Import from Cargo.lock                                      │
│   - Libraries hidden from users                                 │
│   - Stored in rust-crates and rust-sources modules              │
└─────────────────────────────────────────────────────────────────┘
```

### New Module Structure

| Module | Purpose |
|--------|---------|
| `(gnu packages rust-crates)` | Auto-imported crate sources with `lookup-cargo-inputs` interface |
| `(gnu packages rust-sources)` | Complex definitions requiring manual work (workspaces, unbundling) |

### Import Workflow

```bash
# NEW: Import from Cargo.lock
guix import crate --lockfile=/path/to/Cargo.lock PACKAGE \
     --insert=gnu/packages/rust-crates.scm

# Short form
guix import -i gnu/packages/rust-crates.scm crate -f Cargo.lock PACKAGE
```

### Package Definition Style

```scheme
;; NEW STYLE (Current)
(define-public my-rust-app
  (package
    (name "my-rust-app")
    (version "1.0.0")
    (source
     (origin
       (method git-fetch)
       (uri (git-reference
             (url "https://github.com/org/repo")
             (commit "...")))
       (sha256 (base32 "..."))))
    (build-system cargo-build-system)
    ;; NEW: Use cargo-inputs procedure
    (inputs (cargo-inputs 'my-rust-app))
    (home-page "...")
    (synopsis "...")
    (description "...")
    (license license:asl2.0)))
```

### For Development (guix.scm)

```scheme
;; In your project's guix.scm
(use-modules (guix import crate))

(package
  (name "my-project")
  (version "0.1.0")
  (source (local-file "." #:recursive? #t))
  (build-system cargo-build-system)
  ;; Read directly from Cargo.lock
  (inputs (cargo-inputs-from-lockfile "Cargo.lock"))
  ...)
```

### Crate Modifications

The new model supports modifications via snippets:

```scheme
;; In rust-crates.scm - Modified crate
(define rust-libmimalloc-sys-0.1.24
  (crate-source "libmimalloc-sys" "0.1.24"
                "0s8ab4nc33qgk9jybpv0zxcb75jgwwjb7fsab1rkyjgdyr0gq1bp"
                #:snippet
                '(begin
                   (delete-file-recursively "c_src")
                   (delete-file "build.rs")
                   (with-output-to-file "build.rs"
                     (lambda _
                       (format #t "fn main() {~@
                        println!(\"cargo:rustc-link-lib=mimalloc\");~@
                        }~%"))))))

;; Replacement (points to rust-sources definition)
(define rust-pipewire-0.8.0 rust-pipewire-for-niri)

;; Deletion
(define rust-problematic-crate-1.0.0 #f)
```

---

## Git Dependencies: The Key Insight

### The Two-Module System

```
┌─────────────────────────────────────────────────────────────────────┐
│                      GUIX RUST MODEL                                 │
│                                                                      │
│   rust-crates.scm                      rust-sources.scm             │
│   ───────────────                      ─────────────────            │
│   AUTO-GENERATED                       MANUALLY DEFINED             │
│   via importer                         for complex cases            │
│                                                                      │
│   • crates.io sources                  • Git dependencies           │
│   • Simple hash-verified               • Development snapshots      │
│   • No modifications                   • Modified crates (snippets) │
│                                        • Workspace crates           │
│                                                                      │
│   (define rust-serde-1.0.193           (define rust-ring-0.17.8.    │
│     (crate-source "serde"                abc1234                    │
│       "1.0.193" "hash..."))              (origin                    │
│                                            (method git-fetch)       │
│                                            (uri (git-reference      │
│                                              (url "https://...")    │
│                                              (commit "abc...")))    │
│                                            (sha256 ...)))           │
│                                                                      │
│   ─────────────────────────────────────────────────────────────     │
│                              ↓                                       │
│                    lookup-cargo-inputs                              │
│                    ────────────────────                             │
│                    Combines BOTH modules                            │
│                              ↓                                       │
│             ┌────────────────────────────────┐                      │
│             │    (cargo-inputs 'xous-core)   │                      │
│             │    Returns: ALL dependencies   │                      │
│             └────────────────────────────────┘                      │
└─────────────────────────────────────────────────────────────────────┘
```

### Naming Convention for Git Dependencies

```scheme
;; Format: rust-CRATE-VERSION.COMMIT_PREFIX
;; VERSION from Cargo.toml in the repo
;; COMMIT_PREFIX is first 7 chars of commit hash

;; Examples:
rust-curve25519-dalek-4.1.3.a66fad2    ; version 4.1.3, commit a66fad2...
rust-ring-0.17.8.abc1234               ; version 0.17.8, commit abc1234...
rust-pipewire-0.8.0.fd3d8f7            ; development snapshot
```

### How cargo-build-system Handles Git Sources

The configure phase in `cargo-build-system`:

1. Creates `guix-vendor/` directory
2. Unpacks ALL input sources (crates.io AND git)
3. For crates.io: Uses original checksum in `.cargo-checksum.json`
4. For git sources: Uses **empty hash** (cargo doesn't verify git checksums)
5. Configures `.cargo/config.toml` for offline vendored build

**This is why the model works for git dependencies** - cargo itself treats git deps differently from registry deps.

---

## Threat Model

### Attack Vectors

| Vector | Description | Risk Level |
|--------|-------------|------------|
| **Compromised Maintainer** | Attacker gains access to crates.io account | Critical |
| **Dependency Confusion** | Malicious package with same name as internal dep | High |
| **Typosquatting** | Similar name attack (e.g., `serde` vs `serdee`) | High |
| **Index Poisoning** | Manipulation of crates.io index | High |
| **Git Ref Mutation** | Force-push or repo recreation | High |
| **Build Script Attacks** | Malicious `build.rs` or proc-macro | Critical |
| **Toolchain Compromise** | Backdoored rustc or cargo | Critical |
| **Transitive Dependencies** | Attack through nested dependency | High |

### Security Goals

1. **Reproducibility** - Same inputs always produce same outputs
2. **Auditability** - Every dependency traceable to its source
3. **Verifiability** - Independent verification of all artifacts
4. **Isolation** - Build process cannot fetch additional code

---

## Security Architecture

### How the New Model Helps Security

```
┌─────────────────────────────────────────────────────────────────┐
│                   SECURITY BENEFITS                              │
│                                                                  │
│   1. Cargo.lock is source of truth                              │
│      - Exact versions pinned                                    │
│      - Checksums recorded                                       │
│      - Guix imports from this                                   │
│                                                                  │
│   2. Sources stored, not artifacts                              │
│      - Can be audited                                           │
│      - Can be modified via snippets                             │
│      - Full transparency                                        │
│                                                                  │
│   3. Guix handles verification                                  │
│      - Hash verification on fetch                               │
│      - Reproducible builds                                      │
│      - Network isolation                                        │
│                                                                  │
│   4. Modifications are explicit                                 │
│      - Snippets visible in package definition                   │
│      - Replacements documented                                  │
│      - Deletions tracked                                        │
└─────────────────────────────────────────────────────────────────┘
```

### What You Still Need

The new Guix model provides infrastructure, but **does not verify authenticity**. You still need:

1. **cargo-vet** - Human audit attestations
2. **Software Heritage** - Independent verification
3. **Provenance tracking** - Your own audit trail

---

## Trust Anchors

### 1. cargo-vet (Primary Trust Anchor)

cargo-vet records human attestations that crates have been reviewed.

```bash
# Initialize
cargo vet init

# Import trusted audits
cargo vet trust --all mozilla
cargo vet trust --all google
cargo vet trust --all bytecode-alliance

# Check status
cargo vet

# After reviewing, certify
cargo vet certify CRATE VERSION safe-to-deploy

# Or exempt with rationale
cargo vet add-exemption CRATE VERSION --notes "Rationale"
```

This creates `supply-chain/` directory:
- `config.toml` - Whose audits to trust
- `audits.toml` - Your attestations
- `imports.lock` - Imported audit versions

### 2. Software Heritage (Independent Verification)

Cross-check crates against Software Heritage archives:

```python
def check_software_heritage(sha256: str) -> bool:
    """Verify crate exists in Software Heritage."""
    url = f"https://archive.softwareheritage.org/api/1/content/sha256:{sha256}/"
    try:
        response = urlopen(url, timeout=30)
        return response.status == 200
    except:
        return False
```

### 3. Guix Content-Addressed Storage

Guix verifies hashes on every fetch:

```scheme
(source
 (origin
   (method url-fetch)
   (uri (crate-uri "serde" "1.0.193"))
   ;; This hash is verified by Guix
   (sha256 (base32 "1hyr7k1z24i3approhx60spsg44d0m2vg7zn8lgxy5ya458x5qhx7"))))
```

---

## Implementation for xous-core

### Project Dependencies

| Type | Count | Examples |
|------|-------|----------|
| crates.io | ~200+ | serde, tokio, etc. |
| Git (betrusted-io) | 15 | curve25519-dalek, ring, usb-device |
| Workspace members | Many | xous-*, libs/* |

### Step 1: Extract Git Dependencies from Cargo.lock

```python
#!/usr/bin/env python3
"""extract-git-deps.py - Generate rust-sources.scm entries"""

import tomllib
import subprocess
import os

def get_guix_hash(url, commit):
    """Get hash via guix download."""
    try:
        result = subprocess.run(
            ["guix", "hash", "-rx", "--exclude-vcs", "."],
            capture_output=True, text=True, cwd=f"/tmp/guix-hash-{commit[:7]}"
        )
        return result.stdout.strip()
    except:
        return "COMPUTE_THIS_HASH"

def main():
    with open("Cargo.lock", "rb") as f:
        lock = tomllib.load(f)
    
    git_deps = []
    for pkg in lock.get("package", []):
        source = pkg.get("source", "")
        if source.startswith("git+"):
            name = pkg["name"]
            version = pkg["version"]
            url = source.split("#")[0].replace("git+", "").split("?")[0]
            commit = source.split("#")[1] if "#" in source else "unknown"
            
            git_deps.append({
                "name": name,
                "version": version,
                "url": url,
                "commit_short": commit[:7],
                "commit_full": commit,
            })
    
    print(";;; rust-sources.scm entries for xous-core git dependencies")
    print(";;; Generated from Cargo.lock")
    print()
    
    for dep in git_deps:
        var_name = f"rust-{dep['name']}-{dep['version']}.{dep['commit_short']}"
        print(f";; {dep['name']} from {dep['url']}")
        print(f"(define {var_name}")
        print(f"  (origin")
        print(f"    (method git-fetch)")
        print(f"    (uri (git-reference")
        print(f"          (url \"{dep['url']}\")")
        print(f"          (commit \"{dep['commit_full']}\")))")
        print(f"    (file-name \"{var_name}-checkout\")")
        print(f"    (sha256 (base32 \"COMPUTE_WITH_GUIX_HASH\"))))")
        print()

if __name__ == "__main__":
    main()
```

### Step 2: Compute Hashes

For each git dependency:

```bash
# Clone and checkout specific commit
git clone --depth 1 https://github.com/betrusted-io/curve25519-dalek /tmp/hash-work
cd /tmp/hash-work
git fetch --depth 1 origin FULL_COMMIT_HASH
git checkout FULL_COMMIT_HASH

# Compute Guix hash
guix hash -rx .
# Output: 0abc123... (use this in sha256 field)
```

Or use a script to batch process:

```bash
#!/bin/bash
# compute-hashes.sh

declare -A DEPS
DEPS["curve25519-dalek"]="https://github.com/betrusted-io/curve25519-dalek|COMMIT"
DEPS["ring"]="https://github.com/betrusted-io/ring|COMMIT"
# ... add all git deps

for name in "${!DEPS[@]}"; do
    IFS='|' read -r url commit <<< "${DEPS[$name]}"
    echo "=== $name ==="
    tmpdir=$(mktemp -d)
    git clone --depth 1 "$url" "$tmpdir"
    cd "$tmpdir"
    git fetch --depth 1 origin "$commit"
    git checkout "$commit"
    hash=$(guix hash -rx .)
    echo "$name: $hash"
    rm -rf "$tmpdir"
done
```

### Step 3: Create rust-sources.scm Entries

```scheme
;;; gnu/packages/rust-sources.scm (or your channel)
;;; xous-core git dependencies

(define-module (gnu packages rust-sources)
  #:use-module (guix packages)
  #:use-module (guix git-download)
  #:use-module ((guix licenses) #:prefix license:))

;; betrusted-io/curve25519-dalek fork
;; Security-critical: constant-time implementations for Precursor
(define rust-curve25519-dalek-4.1.3.a66fad2
  (origin
    (method git-fetch)
    (uri (git-reference
          (url "https://github.com/betrusted-io/curve25519-dalek")
          (commit "a66fad2aab58f8f886f6e85a0012ada164e462c4")))
    (file-name "rust-curve25519-dalek-4.1.3.a66fad2-checkout")
    (sha256
     (base32 "0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"))))

;; betrusted-io/ring fork  
;; Security-critical: cryptographic primitives
(define rust-ring-0.17.8.abc1234
  (origin
    (method git-fetch)
    (uri (git-reference
          (url "https://github.com/betrusted-io/ring")
          (commit "abc1234def5678...")))
    (file-name "rust-ring-0.17.8.abc1234-checkout")
    (sha256
     (base32 "0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"))))

;; Continue for all 15 git dependencies...
;; usb-device, x25519-dalek, ed25519-dalek, etc.
```

### Step 4: Register Dependencies

In `rust-crates.scm` (or your channel's equivalent):

```scheme
(define-cargo-inputs lookup-cargo-inputs
  ;; ... other entries ...
  
  (xous-core => (list 
    ;; crates.io dependencies (imported)
    rust-serde-1.0.193
    rust-tokio-1.35.1
    rust-log-0.4.20
    ;; ... ~200 more from importer ...
    
    ;; Git dependencies (from rust-sources)
    rust-curve25519-dalek-4.1.3.a66fad2
    rust-ring-0.17.8.abc1234
    rust-usb-device-0.3.0.xyz7890
    ;; ... all 15 git deps ...
    )))
```

---

## Handling cargo xtask

### What is cargo xtask?

xous-core uses [cargo xtask](https://github.com/matklad/cargo-xtask) - a convention where build logic lives in Rust code:

```
xous-core/
├── xtask/
│   ├── Cargo.toml
│   └── src/
│       └── main.rs    ← Build orchestration logic
├── kernel/
├── services/
└── ...
```

Running `cargo xtask app-image` compiles the xtask crate, then executes it to orchestrate the build.

### Security Implications

```
┌─────────────────────────────────────────────────────────────────────┐
│                    CARGO XTASK SECURITY                              │
│                                                                      │
│   PHASE 1: xtask Compilation                                        │
│   ─────────────────────────                                         │
│   • xtask/Cargo.toml dependencies are built                         │
│   • build.rs scripts execute (if any)                               │
│   • proc-macros execute                                             │
│                                                                      │
│   Risk: Same as any Rust build                                      │
│   Mitigation: cargo-vet covers xtask deps too                       │
│                                                                      │
│   PHASE 2: xtask Execution                                          │
│   ────────────────────────                                          │
│   • xtask binary runs with full privileges                          │
│   • Can spawn subprocesses, read/write files                        │
│   • Orchestrates actual kernel/app builds                           │
│                                                                      │
│   Risk: Malicious xtask code                                        │
│   Mitigation:                                                       │
│   - Review xtask/src/ code                                          │
│   - Guix sandbox blocks network                                     │
│   - Pass --offline to cargo invocations                             │
│                                                                      │
│   PHASE 3: Sub-builds                                               │
│   ─────────────────                                                 │
│   • xtask invokes cargo build for kernel, services, etc.            │
│   • Each sub-build has its own dependencies                         │
│                                                                      │
│   Risk: Normal Rust build risks                                     │
│   Mitigation: All deps in cargo-vet scope                           │
└─────────────────────────────────────────────────────────────────────┘
```

### Guix Build Phase for xtask

```scheme
(arguments
 (list
  ;; Standard cargo phases won't work - we use xtask
  #:skip-build? #t
  #:install-source? #f
  
  #:phases
  #~(modify-phases %standard-phases
      ;; Keep these standard phases:
      ;; - unpack
      ;; - unpack-rust-crates (unpacks dependencies)
      ;; - configure (sets up vendor directory)
      ;; - check-for-pregenerated-files
      ;; - patch-cargo-checksums
      
      ;; Replace build with xtask invocation
      (replace 'build
        (lambda* (#:key parallel-build? #:allow-other-keys)
          (let ((job-count (if parallel-build?
                               (number->string (parallel-job-count))
                               "1")))
            ;; Environment setup
            (setenv "CARGO_HOME" 
                    (string-append (getcwd) "/.cargo-home"))
            (mkdir-p (getenv "CARGO_HOME"))
            
            ;; CRITICAL: Force offline mode
            (setenv "CARGO_NET_OFFLINE" "true")
            
            ;; Run xtask
            ;; Adjust arguments based on what you want to build
            (invoke "cargo" "xtask" "app-image"
                    "--offline"
                    "--locked"
                    "-j" job-count
                    ;; Add any xous-specific flags
                    ))))
      
      ;; Tests require RISC-V emulation - skip or handle specially
      (replace 'check
        (lambda _
          (format #t "Skipping tests (require RISC-V emulation)~%")
          #t))
      
      ;; Custom install for xous artifacts
      (replace 'install
        (lambda* (#:key outputs #:allow-other-keys)
          (let* ((out (assoc-ref outputs "out"))
                 (share (string-append out "/share/xous"))
                 (bin (string-append out "/bin")))
            (mkdir-p share)
            (mkdir-p bin)
            
            ;; Install images
            (for-each
             (lambda (f) (install-file f share))
             (find-files "target" "\\.(img|bin)$"))
            
            ;; Install any host tools
            (when (file-exists? "target/release/xtask")
              (install-file "target/release/xtask" bin))))))))
```

---

## Guix Integration

### Complete Package Definition for xous-core

```scheme
;;; gnu/packages/xous.scm

(define-module (gnu packages xous)
  #:use-module (guix packages)
  #:use-module (guix gexp)
  #:use-module (guix git-download)
  #:use-module (guix build-system cargo)
  #:use-module ((guix licenses) #:prefix license:)
  #:use-module (gnu packages rust)
  #:use-module (gnu packages rust-crates)
  #:use-module (gnu packages rust-sources)
  #:use-module (gnu packages pkg-config)
  #:use-module (gnu packages llvm))

;; Pin exact versions for reproducibility
(define %xous-version "0.9.x")
(define %xous-commit "YOUR_PINNED_COMMIT_HASH")

(define-public xous-core
  (package
    (name "xous-core")
    (version %xous-version)
    (source
     (origin
       (method git-fetch)
       (uri (git-reference
             (url "https://github.com/betrusted-io/xous-core")
             (commit %xous-commit)))
       (file-name (git-file-name name version))
       (sha256 (base32 "YOUR_SOURCE_HASH"))))
    
    (build-system cargo-build-system)
    
    ;; Dependencies from BOTH rust-crates and rust-sources
    (inputs (cargo-inputs 'xous-core))
    
    ;; Non-Rust build dependencies
    (native-inputs
     (list pkg-config))
    
    (arguments
     (list
      ;; We use xtask, not standard cargo build
      #:skip-build? #t
      #:install-source? #f
      
      ;; Tests require RISC-V emulation
      #:tests? #f
      
      #:phases
      #~(modify-phases %standard-phases
          ;; Verify cargo-vet data is present
          (add-after 'unpack 'check-audit-data
            (lambda _
              (if (file-exists? "supply-chain/audits.toml")
                  (format #t "✓ cargo-vet audit data present~%")
                  (format #t "⚠ No cargo-vet data found~%"))))
          
          ;; Build using xtask
          (replace 'build
            (lambda* (#:key parallel-build? #:allow-other-keys)
              (let ((job-count (if parallel-build?
                                   (number->string (parallel-job-count))
                                   "1")))
                ;; Set up cargo environment
                (setenv "CARGO_HOME" 
                        (string-append (getcwd) "/.cargo-home"))
                (mkdir-p (getenv "CARGO_HOME"))
                
                ;; CRITICAL: Ensure offline mode
                (setenv "CARGO_NET_OFFLINE" "true")
                
                ;; Build with xtask
                ;; Adjust command for your specific build target
                (invoke "cargo" "xtask" "app-image"
                        "--offline"
                        "--locked"
                        "-j" job-count))))
          
          ;; Skip check phase (tests need emulation)
          (delete 'check)
          
          ;; Install artifacts
          (replace 'install
            (lambda* (#:key outputs #:allow-other-keys)
              (let* ((out (assoc-ref outputs "out"))
                     (share (string-append out "/share/xous"))
                     (doc (string-append out "/share/doc/xous-core")))
                
                ;; Create directories
                (mkdir-p share)
                (mkdir-p doc)
                
                ;; Install built images
                (for-each
                 (lambda (f) 
                   (format #t "Installing: ~a~%" f)
                   (install-file f share))
                 (find-files "target" "\\.(img|bin|elf)$"))
                
                ;; Install documentation
                (when (file-exists? "README.md")
                  (install-file "README.md" doc))
                (when (file-exists? "TRUST_POLICY.md")
                  (install-file "TRUST_POLICY.md" doc))))))))
    
    (home-page "https://github.com/betrusted-io/xous-core")
    (synopsis "Xous microkernel operating system")
    (description
     "Xous is a microkernel operating system written in Rust, designed
for the Precursor secure communication device.  It provides a minimal,
security-focused kernel with message-passing IPC.")
    (license license:asl2.0)))
```

### For Local Development: guix.scm

```scheme
;;; guix.scm - Development environment
;;; Usage: guix shell

(use-modules (guix packages)
             (guix gexp)
             (guix import crate)
             (guix build-system cargo)
             (gnu packages rust)
             (gnu packages llvm)
             (gnu packages pkg-config))

(define %source-dir (dirname (current-filename)))

(package
  (name "xous-core-dev")
  (version "0.0.0-dev")
  (source (local-file %source-dir 
                      #:recursive? #t
                      #:select? (git-predicate %source-dir)))
  (build-system cargo-build-system)
  
  (arguments
   (list
    #:skip-build? #t  ; Just provide environment
    #:phases
    #~(modify-phases %standard-phases
        (delete 'build)
        (delete 'check)
        (delete 'install))))
  
  ;; Note: cargo-inputs-from-lockfile only gets crates.io deps
  ;; For git deps, you'll need to use cargo vendor separately
  ;; or define them in your channel
  (inputs 
   (cons* rust 
          (list rust "cargo")
          (list rust "tools")  ; clippy, rustfmt
          pkg-config
          ;; Add crates.io deps from lockfile
          (cargo-inputs-from-lockfile "Cargo.lock")))
  
  (home-page "")
  (synopsis "Xous development environment")
  (description "")
  (license #f))
```

### Guix Channel for xous-core

If maintaining your own channel:

```scheme
;;; .guix-channel
(channel
 (version 0)
 (directory "guix")
 (dependencies
  (channel
   (name guix)
   (url "https://git.savannah.gnu.org/git/guix.git")
   (branch "master"))))
```

```
your-channel/
├── .guix-channel
└── guix/
    └── packages/
        ├── xous.scm           # Main package
        ├── xous-rust-crates.scm   # crates.io deps
        └── xous-rust-sources.scm  # Git deps
```

---

## Verification Procedures

### Pre-Import Verification Script

```bash
#!/bin/bash
# verify-before-import.sh
# Run before guix import to verify dependencies

set -euo pipefail

echo "=== Pre-Import Verification ==="

# 1. Check Cargo.lock exists and is committed
echo "[1/4] Checking Cargo.lock..."
if [[ ! -f Cargo.lock ]]; then
    echo "ERROR: Cargo.lock not found"
    exit 1
fi
if ! git ls-files --error-unmatch Cargo.lock &>/dev/null; then
    echo "WARNING: Cargo.lock not committed"
fi
echo "  ✓ Cargo.lock present"

# 2. Check cargo-vet status
echo "[2/4] Checking cargo-vet..."
if command -v cargo-vet &>/dev/null; then
    if cargo vet --locked 2>/dev/null; then
        echo "  ✓ All dependencies audited or exempted"
    else
        echo "  ⚠ Some dependencies not audited"
        cargo vet suggest 2>/dev/null | head -20
    fi
else
    echo "  ⚠ cargo-vet not installed"
fi

# 3. Count dependencies
echo "[3/4] Counting dependencies..."
dep_count=$(grep -c '^\[\[package\]\]' Cargo.lock || echo "0")
echo "  Total packages in Cargo.lock: $dep_count"

# 4. Check for git dependencies
echo "[4/4] Checking for git dependencies..."
git_deps=$(grep -c 'source = "git+' Cargo.lock || echo "0")
if [[ "$git_deps" -gt 0 ]]; then
    echo "  ⚠ Found $git_deps git dependencies (may need rust-sources.scm entries)"
    grep 'source = "git+' Cargo.lock | head -10
else
    echo "  ✓ No git dependencies"
fi

echo ""
echo "=== Verification complete ==="
```

### Software Heritage Verification Script

```python
#!/usr/bin/env python3
"""verify-swh.py - Verify crates against Software Heritage"""

import hashlib
import json
import tomllib
from pathlib import Path
from urllib.request import urlopen, Request
from urllib.error import HTTPError

def get_crate_hash(name: str, version: str) -> str:
    """Fetch crate and compute SHA256."""
    url = f"https://static.crates.io/crates/{name}/{name}-{version}.crate"
    with urlopen(url, timeout=60) as resp:
        return hashlib.sha256(resp.read()).hexdigest()

def check_swh(sha256: str) -> bool:
    """Check if Software Heritage knows this hash."""
    url = f"https://archive.softwareheritage.org/api/1/content/sha256:{sha256}/"
    try:
        with urlopen(url, timeout=30) as resp:
            return resp.status == 200
    except HTTPError as e:
        if e.code == 404:
            return False
        raise

def main():
    # Parse Cargo.lock
    with open("Cargo.lock", "rb") as f:
        lock = tomllib.load(f)
    
    results = {"verified": [], "not_found": [], "errors": []}
    
    for pkg in lock.get("package", []):
        name = pkg["name"]
        version = pkg["version"]
        source = pkg.get("source", "")
        
        # Skip non-crates.io sources
        if not source.startswith("registry+"):
            continue
        
        print(f"Checking {name}-{version}...", end=" ")
        
        try:
            sha256 = get_crate_hash(name, version)
            if check_swh(sha256):
                print("✓ verified")
                results["verified"].append(f"{name}-{version}")
            else:
                print("⚠ not in SWH")
                results["not_found"].append(f"{name}-{version}")
        except Exception as e:
            print(f"✗ error: {e}")
            results["errors"].append(f"{name}-{version}: {e}")
    
    # Summary
    print("\n=== Summary ===")
    print(f"Verified in SWH: {len(results['verified'])}")
    print(f"Not found in SWH: {len(results['not_found'])}")
    print(f"Errors: {len(results['errors'])}")
    
    # Save results
    with open(".provenance/swh-verification.json", "w") as f:
        json.dump(results, f, indent=2)

if __name__ == "__main__":
    main()
```

### CI/CD Integration

```yaml
# .github/workflows/verify-deps.yml
name: Verify Dependencies

on:
  pull_request:
    paths:
      - 'Cargo.lock'
      - 'supply-chain/**'

jobs:
  cargo-vet:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Install cargo-vet
        run: cargo install cargo-vet
      
      - name: Check audits
        run: cargo vet --locked
      
      - name: Suggest missing
        if: failure()
        run: cargo vet suggest

  guix-import-check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Install Guix
        uses: PromyLOPh/guix-install-action@v1
      
      - name: Test import
        run: |
          guix import crate --lockfile=Cargo.lock xous-core \
               > /tmp/imported.scm
          echo "Import successful, $(wc -l < /tmp/imported.scm) lines"
```

---

## Workflow

### Initial Setup

```bash
# 1. Clone repository
git clone https://github.com/betrusted-io/xous-core
cd xous-core

# 2. Initialize cargo-vet
cargo vet init
cargo vet trust --all mozilla google bytecode-alliance

# 3. Run initial audit check
cargo vet
cargo vet suggest  # Address unaudited crates

# 4. Extract git dependencies
python3 extract-git-deps.py > /tmp/git-deps.scm

# 5. Compute hashes for git deps
./compute-git-hashes.sh  # Creates hash list

# 6. Import crates.io dependencies
guix import crate --lockfile=Cargo.lock xous-core \
     --insert=gnu/packages/rust-crates.scm
# Note: This will skip git deps with warnings - that's expected!

# 7. Create rust-sources.scm with git deps
# Use the extract-git-deps.py output, fill in computed hashes

# 8. Register in lookup-cargo-inputs
# Add xous-core => (list ...) with ALL dependencies

# 9. Create trust policy document
cat > TRUST_POLICY.md << 'EOF'
# Trust Policy for xous-core

## Trusted Audit Sources
- Mozilla, Google, Bytecode Alliance

## Git Dependencies
All git dependencies are betrusted-io forks of:
- curve25519-dalek (constant-time crypto)
- ring (cryptographic primitives)
- usb-device (hardware interface)
- ... etc.

These are pinned to specific commits in Cargo.lock.

## Known Trust Gaps
- Rust compiler not yet fully bootstrapped in Guix
- xtask binary executes during build (reviewed)

## Verification
- All crates.io deps pass cargo-vet
- Git deps pinned to commit hashes
- Build is fully offline
EOF

# 10. Commit everything
git add Cargo.lock supply-chain/ TRUST_POLICY.md
git commit -m "Initialize supply chain security"
```

### Updating Dependencies

```bash
# 1. Update Cargo.lock
cargo update

# 2. Check for new git deps
python3 extract-git-deps.py > /tmp/new-git-deps.scm
diff old-git-deps.scm /tmp/new-git-deps.scm

# 3. Compute hashes for any new/changed git deps

# 4. Check cargo-vet
cargo vet
cargo vet suggest  # Address any new unaudited deps

# 5. Re-import crates.io deps
guix import crate --lockfile=Cargo.lock xous-core \
     --insert=gnu/packages/rust-crates.scm

# 6. Update rust-sources.scm if git deps changed

# 7. Update lookup-cargo-inputs mapping

# 8. Test build
guix build -f guix.scm

# 9. Commit
git add Cargo.lock supply-chain/ 
git add gnu/packages/rust-crates.scm
git add gnu/packages/rust-sources.scm
git commit -m "Update dependencies"
```

### Building

```bash
# Standard Guix build
guix build xous-core

# With verbosity (to see xtask output)
guix build xous-core -v2

# Check reproducibility
guix build xous-core --check

# Build from local channel
guix build -L /path/to/your-channel xous-core

# Development shell (crates.io deps only)
guix shell -f guix.scm
# Then manually: cargo vendor for git deps
```

### Complete Build Verification

```bash
#!/bin/bash
# verify-build.sh

set -euo pipefail

echo "=== Verifying xous-core Build ==="

# 1. Check cargo-vet
echo "[1/5] Checking cargo-vet..."
cargo vet --locked

# 2. Verify Cargo.lock is committed
echo "[2/5] Checking Cargo.lock..."
if ! git ls-files --error-unmatch Cargo.lock &>/dev/null; then
    echo "ERROR: Cargo.lock not committed"
    exit 1
fi

# 3. Count dependencies
echo "[3/5] Counting dependencies..."
total=$(grep -c '^\[\[package\]\]' Cargo.lock)
git_deps=$(grep -c 'source = "git+' Cargo.lock || echo "0")
echo "  Total: $total, Git: $git_deps"

# 4. Build with Guix
echo "[4/5] Building with Guix..."
guix build -L . xous-core

# 5. Verify reproducibility
echo "[5/5] Checking reproducibility..."
guix build -L . xous-core --check

echo ""
echo "=== Build Verified Successfully ==="
```

---

## Path to Fully Bootstrapped Rust

### The Bootstrap Problem

Rust is written in Rust, creating a circular dependency:

```
rustc 1.75 needs rustc 1.74 to compile
rustc 1.74 needs rustc 1.73 to compile
...
```

### The Solution: mrustc

[mrustc](https://github.com/thepowersgang/mrustc) is a Rust compiler written in C++ that can compile specific rustc versions.

```
┌─────────────────────────────────────────────────────────────────┐
│                 BOOTSTRAP CHAIN (Goal)                           │
│                                                                  │
│   GNU Mes (Scheme) → mescc → TinyCC → GCC 4.6 → Modern GCC      │
│                                                                  │
│                              ↓                                   │
│                                                                  │
│                          mrustc (C++)                            │
│                              ↓                                   │
│                       rustc 1.54 (first)                        │
│                              ↓                                   │
│                 rustc 1.55 → 1.56 → ... → current               │
└─────────────────────────────────────────────────────────────────┘
```

### Current Status in Guix

As of 2025:
- **Complete:** Mes → TinyCC → GCC bootstrap chain
- **In Progress:** mrustc integration, Rust version stepping
- **Workaround:** Guix currently uses pre-built rustc binaries

### What This Means for xous-core

```
┌─────────────────────────────────────────────────────────────────┐
│              TRUST CHAIN FOR XOUS-CORE                           │
│                                                                  │
│   VERIFIED BY GUIX:                                             │
│   ✓ All crate sources (hash-checked)                            │
│   ✓ Build isolation (no network)                                │
│   ✓ Reproducible builds                                         │
│                                                                  │
│   VERIFIED BY YOU:                                              │
│   ✓ cargo-vet audits                                            │
│   ✓ Software Heritage cross-check                               │
│   ✓ Provenance documentation                                    │
│                                                                  │
│   TRUSTED (NOT YET VERIFIED):                                   │
│   ! Rust compiler (rustc bootstrap binaries)                    │
│   ! LLVM backend                                                │
│                                                                  │
│   Document this gap in TRUST_POLICY.md                          │
└─────────────────────────────────────────────────────────────────┘
```

### Tracking Progress

```bash
# See Rust package build graph
guix graph rust | dot -Tpng > rust-graph.png

# Check for bootstrap status
guix graph --type=bag rust | grep bootstrap
```

---

## Limitations and Known Gaps

### What's Protected

| Threat | Protection | Mechanism |
|--------|------------|-----------|
| Compromised crate maintainer | ✓ Yes | cargo-vet audits |
| crates.io service compromise | ✓ Yes | SWH cross-verification |
| Index poisoning | ✓ Yes | Guix hash verification |
| Typosquatting | ✓ Yes | Cargo.lock + audits |
| Network MITM at build | ✓ Yes | Guix offline builds |
| Binary substitution | ✓ Yes | Reproducible builds |

### What's NOT Protected

| Threat | Gap | Mitigation |
|--------|-----|------------|
| **Rust toolchain** | Not fully bootstrapped | Document; await Guix progress |
| **Malicious build.rs** | Executes during build | Audit in cargo-vet review |
| **Proc-macro attacks** | Executes at compile | Audit proc-macros carefully |
| **0-day in audited crate** | Audits aren't perfect | Defense in depth |

### Honest Trust Statement

```markdown
## Known Trust Gaps (for TRUST_POLICY.md)

### Rust Compiler Bootstrap
Guix does not yet have a fully bootstrapped Rust compiler.
The `rust` package uses pre-built bootstrap binaries from
static.rust-lang.org.

**Risk:** We trust Rust project's release infrastructure.

**Mitigations:**
- Pin exact Guix commit for builds
- Pin exact Rust version
- Verify reproducibility with `guix build --check`
- Will adopt bootstrapped Rust when Guix completes it

**Tracking:** https://issues.guix.gnu.org (search "rust bootstrap")
```

---

## Appendix: Tools and Scripts

### A. Guix Import with Verification

```bash
#!/bin/bash
# secure-import.sh - Import with pre/post verification

set -euo pipefail

LOCKFILE="${1:-Cargo.lock}"
PACKAGE="${2:-$(basename $(pwd))}"

echo "=== Secure Import Workflow ==="

# Pre-import checks
echo "[1/4] Running cargo-vet..."
cargo vet --locked

echo "[2/4] Importing from $LOCKFILE..."
guix import crate --lockfile="$LOCKFILE" "$PACKAGE" \
     > /tmp/new-crates.scm

echo "[3/4] Checking import..."
lines=$(wc -l < /tmp/new-crates.scm)
echo "  Generated $lines lines"

echo "[4/4] Done!"
echo ""
echo "Review /tmp/new-crates.scm then merge into rust-crates.scm"
```

### B. Audit Helper Script

```bash
#!/bin/bash
# audit-new-deps.sh - Help audit new dependencies

# Get list of unaudited crates
unaudited=$(cargo vet suggest 2>/dev/null | grep -oP 'cargo vet certify \K[^ ]+' || true)

if [[ -z "$unaudited" ]]; then
    echo "All dependencies are audited or exempted!"
    exit 0
fi

echo "Unaudited crates:"
echo "$unaudited"
echo ""

for crate in $unaudited; do
    name=$(echo "$crate" | cut -d: -f1)
    version=$(echo "$crate" | cut -d: -f2)
    
    echo "=== $name $version ==="
    echo "Inspect: cargo vet inspect $name $version"
    echo "Diff:    cargo vet diff $name PREV_VERSION $version"
    echo "Certify: cargo vet certify $name $version safe-to-deploy"
    echo "Exempt:  cargo vet add-exemption $name $version"
    echo ""
done
```

### C. Channel Lock File

```scheme
;;; guix/channels-lock.scm
;;; Generated by: guix time-machine --commit=COMMIT -- describe -f channels

(list
 (channel
  (name 'guix)
  (url "https://git.savannah.gnu.org/git/guix.git")
  (branch "master")
  (commit "EXACT_COMMIT_HASH")
  (introduction
   (make-channel-introduction
    "9edb3f66fd807b096b48283debdcddccfea34bad"
    (openpgp-fingerprint
     "BBB0 2DDF 2CEA F6A8 0D1D  E643 A2A0 6DF2 A33A 54FA")))))
```

### D. Complete Package Template

```scheme
;;; Template for high-assurance Rust package

(define-module (my packages my-rust-app)
  #:use-module (guix packages)
  #:use-module (guix gexp)
  #:use-module (guix git-download)
  #:use-module (guix build-system cargo)
  #:use-module ((guix licenses) #:prefix license:))

;; Pin versions explicitly
(define %version "1.0.0")
(define %commit "abc123...")
(define %cargo-inputs-hash
  (base32 "..."))  ; Optional: hash of rust-crates.scm content

(define-public my-rust-app
  (package
    (name "my-rust-app")
    (version %version)
    (source
     (origin
       (method git-fetch)
       (uri (git-reference
             (url "https://github.com/org/my-rust-app")
             (commit %commit)))
       (file-name (git-file-name name version))
       (sha256 (base32 "..."))))
    
    (build-system cargo-build-system)
    
    ;; New model: cargo-inputs procedure
    (inputs (cargo-inputs 'my-rust-app))
    
    (arguments
     (list
      #:tests? #t
      #:cargo-build-flags #~'("--release")
      #:phases
      #~(modify-phases %standard-phases
          (add-after 'unpack 'verify-lockfile
            (lambda _
              (unless (file-exists? "Cargo.lock")
                (error "Cargo.lock missing - required for reproducibility"))))
          (add-after 'install 'install-docs
            (lambda* (#:key outputs #:allow-other-keys)
              (let ((doc (string-append (assoc-ref outputs "out")
                                        "/share/doc/my-rust-app")))
                (mkdir-p doc)
                (copy-file "README.md" (string-append doc "/README.md"))))))))
    
    (home-page "https://example.com/my-rust-app")
    (synopsis "Short description")
    (description "Longer description.")
    (license license:asl2.0)))
```

---

## References

- [A New Rust Packaging Model (Guix Blog, 2025)](https://guix.gnu.org/en/blog/2025/a-new-rust-packaging-model/)
- [guix-rust-registry (Separate repo for rust-crates/sources)](https://codeberg.org/guix/guix-rust-registry)
- [Issue #3824: Workflow Discussion](https://codeberg.org/guix/guix/issues/3824)
- [PR #387: Documentation and Merge Preparation](https://codeberg.org/guix/guix/pulls/387)
- [Guix Cookbook: Packaging Rust Crates](https://guix.gnu.org/cookbook/en/guix-cookbook.html#Packaging-Rust-Crates)
- [cargo-vet Documentation](https://mozilla.github.io/cargo-vet/)
- [Software Heritage](https://www.softwareheritage.org/)
- [Guix Manual - Build Systems](https://guix.gnu.org/manual/en/html_node/Build-Systems.html)
- [cargo xtask Convention](https://github.com/matklad/cargo-xtask)
- [mrustc - Rust Compiler in C++](https://github.com/thepowersgang/mrustc)
- [SLSA Framework](https://slsa.dev/)
- [Reproducible Builds](https://reproducible-builds.org/)

---

## Document History

| Version | Date | Changes |
|---------|------|---------|
| 3.0 | 2026-01 | Corrected: Git deps ARE supported via rust-sources.scm; Added cargo xtask handling |
| 2.0 | 2025-XX | Updated for new Guix Rust model (merged) |
| 1.0 | 2024-XX | Initial version (deprecated `#:cargo-inputs` approach) |

---

*This document is part of the xous-core project's security documentation.*
