# Analysis: Guix New Rust Model for xous-core

## Executive Summary

**The new Guix Rust packaging model CAN handle git dependencies.** The limitation is in the *importer tool*, not the model itself.

| Component | Git Dep Support | Notes |
|-----------|-----------------|-------|
| `guix import crate --lockfile` | ❌ No | Skips git deps |
| `rust-crates.scm` | ❌ No | Auto-imported crates.io only |
| `rust-sources.scm` | ✅ Yes | Manually defined git deps |
| `cargo-inputs` procedure | ✅ Yes | Pulls from both modules |
| `cargo-build-system` | ✅ Yes | Handles any origin type |

---

## How It Actually Works

### Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                      GUIX RUST MODEL                                 │
│                                                                      │
│   rust-crates.scm                      rust-sources.scm             │
│   ───────────────                      ─────────────────            │
│   AUTO-GENERATED                       MANUALLY DEFINED             │
│                                                                      │
│   (define rust-serde-1.0.193           (define rust-ring-0.17.8.    │
│     (crate-source "serde"                abc1234                    │
│       "1.0.193" "hash..."))              (origin                    │
│                                            (method git-fetch)       │
│   (define rust-tokio-1.35.1              (uri (git-reference       │
│     (crate-source "tokio"                  (url "https://...")      │
│       "1.35.1" "hash..."))                 (commit "abc1234")))     │
│                                            (sha256 ...)))           │
│                                                                      │
│   ─────────────────────────────────────────────────────────────     │
│                              ↓                                       │
│                    lookup-cargo-inputs                              │
│                              ↓                                       │
│             ┌────────────────────────────────┐                      │
│             │    (cargo-inputs 'xous-core)   │                      │
│             │    Returns: list of origins    │                      │
│             └────────────────────────────────┘                      │
│                              ↓                                       │
│                    cargo-build-system                               │
│                    ───────────────────                              │
│                    • Unpacks all sources                            │
│                    • Creates vendor directory                       │
│                    • Generates .cargo-checksum.json                 │
│                    • Configures cargo for offline build             │
└─────────────────────────────────────────────────────────────────────┘
```

### The `cargo-build-system` Configure Phase

From the actual source code, the configure phase:

1. Creates `guix-vendor/` directory
2. Unpacks all input sources into it
3. Generates `.cargo-checksum.json` for each (with empty hash for non-crates.io)
4. Creates `.cargo/config.toml` pointing to vendor directory
5. Sets offline mode

**Key insight:** The checksum for git sources is set to the **empty string hash** because cargo doesn't verify checksums for git dependencies - it uses the commit hash instead.

---

## xous-core Specifics

### Current Dependencies (from earlier analysis)

| Type | Count | Examples |
|------|-------|----------|
| crates.io | ~200+ | serde, tokio, etc. |
| Git (betrusted-io) | 15 | curve25519-dalek, ring, usb-device |
| Workspace members | Many | xous-*, libs/* |

### Build System: cargo xtask

xous-core uses `cargo xtask` for building, NOT standard `cargo build`. This means:

```bash
# NOT this:
cargo build --release

# BUT this:
cargo xtask app-image [OPTIONS]
cargo xtask build-kernel
cargo xtask run
```

This requires **custom build phases** in the Guix package.

---

## Implementation Strategy

### Step 1: Define Git Dependencies in rust-sources.scm

For each betrusted-io fork, create an entry:

```scheme
;;; gnu/packages/rust-sources.scm (or your channel's equivalent)

;; Naming convention: rust-CRATE-VERSION.COMMIT_PREFIX
;; Version comes from Cargo.toml in the repo

(define rust-curve25519-dalek-4.1.3.a66fad2
  (origin
    (method git-fetch)
    (uri (git-reference
          (url "https://github.com/betrusted-io/curve25519-dalek")
          (commit "a66fad2aab58f8f886f6e85a0012ada164e462c4")))
    (file-name "rust-curve25519-dalek-4.1.3.a66fad2-checkout")
    (sha256
     (base32 "0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"))))

(define rust-ring-0.17.8.abc1234
  (origin
    (method git-fetch)
    (uri (git-reference
          (url "https://github.com/betrusted-io/ring")
          (commit "abc1234...")))
    (file-name "rust-ring-0.17.8.abc1234-checkout")
    (sha256
     (base32 "0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"))))

;; ... repeat for all 15 git dependencies
```

### Step 2: Register in lookup-cargo-inputs

The `define-cargo-inputs` macro maps package names to their dependencies:

```scheme
(define-cargo-inputs lookup-cargo-inputs
  ;; ... other packages ...
  (xous-core => (list rust-serde-1.0.193
                      rust-tokio-1.35.1
                      ;; Git deps from rust-sources
                      rust-curve25519-dalek-4.1.3.a66fad2
                      rust-ring-0.17.8.abc1234
                      ;; ... all dependencies
                      )))
```

### Step 3: Package Definition with cargo xtask

```scheme
;;; gnu/packages/xous.scm (or your channel)

(define-module (gnu packages xous)
  #:use-module (guix packages)
  #:use-module (guix gexp)
  #:use-module (guix git-download)
  #:use-module (guix build-system cargo)
  #:use-module ((guix licenses) #:prefix license:)
  #:use-module (gnu packages rust)
  #:use-module (gnu packages rust-crates)
  #:use-module (gnu packages rust-sources))

(define %xous-version "0.9.x")
(define %xous-commit "COMMIT_HASH")

(define-public xous-core
  (package
    (name "xous-core")
    (version %xous-version)
    (source
     (origin
       (method git-fetch)
       (uri (git-reference
             (url "https://github.com/betrusted-io/xous-core")
             (commit %xous-commit)))
       (file-name (git-file-name name version))
       (sha256 (base32 "..."))))
    
    (build-system cargo-build-system)
    
    ;; Pull dependencies from both rust-crates and rust-sources
    (inputs (cargo-inputs 'xous-core))
    
    (arguments
     (list
      ;; Don't use standard cargo build - we use xtask
      #:skip-build? #t
      #:install-source? #f
      
      ;; Custom target (riscv32imac-unknown-xous-elf)
      ;; Note: This requires a custom Rust toolchain
      
      #:phases
      #~(modify-phases %standard-phases
          ;; Keep: unpack, unpack-rust-crates, configure, 
          ;;       check-for-pregenerated-files, patch-cargo-checksums
          
          ;; Replace the build phase with xtask
          (replace 'build
            (lambda* (#:key parallel-build? #:allow-other-keys)
              (let ((job-count (if parallel-build?
                                   (number->string (parallel-job-count))
                                   "1")))
                ;; Set up environment
                (setenv "CARGO_HOME" 
                        (string-append (getcwd) "/.cargo-home"))
                (mkdir-p (getenv "CARGO_HOME"))
                
                ;; Build using xtask
                ;; Adjust command based on what you want to build
                (invoke "cargo" "xtask" "app-image"
                        "--offline"
                        "--locked"
                        "-j" job-count))))
          
          ;; Skip standard check - tests need emulation
          (delete 'check)
          
          ;; Custom install
          (replace 'install
            (lambda* (#:key outputs #:allow-other-keys)
              (let* ((out (assoc-ref outputs "out"))
                     (share (string-append out "/share/xous")))
                (mkdir-p share)
                ;; Install built images
                (for-each
                 (lambda (f) (install-file f share))
                 (find-files "target" "\\.(img|bin|elf)$"))))))))
    
    (home-page "https://github.com/betrusted-io/xous-core")
    (synopsis "Xous microkernel operating system")
    (description "Xous is a microkernel operating system designed for 
the Precursor secure communication device.")
    (license license:asl2.0)))
```

### Step 4: Development Workflow (guix.scm)

For local development without full Guix packaging:

```scheme
;;; guix.scm - for `guix shell` development

(use-modules (guix packages)
             (guix gexp)
             (guix import crate)
             (guix build-system cargo)
             (gnu packages rust))

;; For development, use cargo-inputs-from-lockfile
;; Note: This won't handle git deps - you need cargo vendor for those
(define %source-dir (dirname (current-filename)))

(package
  (name "xous-core-dev")
  (version "0.0.0")
  (source (local-file %source-dir 
                      #:recursive? #t
                      #:select? (git-predicate %source-dir)))
  (build-system cargo-build-system)
  (arguments
   (list
    #:skip-build? #t  ; Just set up the environment
    #:phases
    #~(modify-phases %standard-phases
        (delete 'build)
        (delete 'check)
        (delete 'install))))
  
  ;; This only gets crates.io deps - git deps need cargo vendor
  (inputs (cargo-inputs-from-lockfile "Cargo.lock"))
  
  (home-page "")
  (synopsis "")
  (description "")
  (license #f))
```

---

## Handling the Custom Target (riscv32imac-unknown-xous-elf)

xous-core requires a custom Rust target. Options:

### Option A: Use Rust Nightly with Custom Target JSON

```scheme
(arguments
 (list
  #:rust rust-nightly  ; You'd need to package this
  #:phases
  #~(modify-phases %standard-phases
      (add-before 'build 'setup-target
        (lambda _
          ;; Copy target spec
          (copy-file "targets/riscv32imac-unknown-xous-elf.json"
                     (string-append (getenv "CARGO_HOME") 
                                    "/targets/riscv32imac-unknown-xous-elf.json"))
          ;; Set RUST_TARGET_PATH
          (setenv "RUST_TARGET_PATH" 
                  (string-append (getenv "CARGO_HOME") "/targets")))))))
```

### Option B: Build Toolchain as Part of Package

xous-core has scripts to build its toolchain. This could be a separate package.

### Option C: Use Pre-built Cross Compiler (Less Reproducible)

Document as a trust gap if using external toolchain.

---

## Getting the Hashes

For each git dependency, compute the hash:

```bash
# For a git dependency
git clone https://github.com/betrusted-io/curve25519-dalek
cd curve25519-dalek
git checkout COMMIT_HASH
guix hash -rx .

# Output: something like 0abc123...
# Use this in (sha256 (base32 "0abc123..."))
```

Or use `guix download`:

```bash
guix download --git --commit=COMMIT_HASH \
    https://github.com/betrusted-io/curve25519-dalek
```

---

## Extracting Git Dependencies from Cargo.lock

Script to identify git dependencies:

```python
#!/usr/bin/env python3
"""extract-git-deps.py - Extract git deps from Cargo.lock"""

import tomllib
from pathlib import Path

def main():
    with open("Cargo.lock", "rb") as f:
        lock = tomllib.load(f)
    
    git_deps = []
    for pkg in lock.get("package", []):
        source = pkg.get("source", "")
        if source.startswith("git+"):
            name = pkg["name"]
            version = pkg["version"]
            # Parse: git+https://github.com/org/repo?rev=HASH#HASH
            # or:    git+https://github.com/org/repo?branch=NAME#HASH
            url_part = source.split("#")[0].replace("git+", "")
            commit = source.split("#")[1] if "#" in source else "unknown"
            
            git_deps.append({
                "name": name,
                "version": version,
                "url": url_part.split("?")[0],
                "commit": commit[:7],  # Short commit for naming
                "full_commit": commit,
            })
    
    print(f"Found {len(git_deps)} git dependencies:\n")
    
    for dep in git_deps:
        print(f";; {dep['name']} {dep['version']}")
        print(f"(define rust-{dep['name']}-{dep['version']}.{dep['commit']}")
        print(f"  (origin")
        print(f"    (method git-fetch)")
        print(f"    (uri (git-reference")
        print(f"          (url \"{dep['url']}\")")
        print(f"          (commit \"{dep['full_commit']}\")))")
        print(f"    (file-name \"rust-{dep['name']}-{dep['version']}.{dep['commit']}-checkout\")")
        print(f"    (sha256 (base32 \"COMPUTE_THIS_HASH\"))))")
        print()

if __name__ == "__main__":
    main()
```

---

## Complete Workflow

```
┌─────────────────────────────────────────────────────────────────────┐
│                    XOUS-CORE GUIX WORKFLOW                           │
│                                                                      │
│  1. EXTRACT GIT DEPS                                                │
│     ./extract-git-deps.py > git-deps.scm                            │
│     # Manually compute hashes with guix hash -rx                    │
│                                                                      │
│  2. IMPORT CRATES.IO DEPS                                           │
│     guix import crate --lockfile=Cargo.lock xous-core \             │
│          --insert=gnu/packages/rust-crates.scm                      │
│                                                                      │
│  3. CREATE RUST-SOURCES ENTRIES                                     │
│     # Add git deps to rust-sources.scm                              │
│                                                                      │
│  4. REGISTER IN LOOKUP-CARGO-INPUTS                                 │
│     # Add xous-core => (list ...) mapping                           │
│                                                                      │
│  5. CREATE PACKAGE DEFINITION                                       │
│     # With custom xtask build phases                                │
│                                                                      │
│  6. BUILD                                                           │
│     guix build xous-core                                            │
│                                                                      │
│  7. VERIFY                                                          │
│     guix build xous-core --check  # Reproducibility                 │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Security Considerations with cargo xtask

### What cargo xtask Does

`cargo xtask` is a convention where build logic lives in a Rust crate. When you run:

```bash
cargo xtask app-image
```

Cargo:
1. Compiles the `xtask` crate (in `xtask/` directory)
2. Runs it as a binary
3. That binary orchestrates the actual build

### Security Implications

| Phase | Risk | Mitigation |
|-------|------|------------|
| xtask compilation | Build.rs in xtask deps | cargo-vet audit |
| xtask execution | Arbitrary code | Review xtask/src/main.rs |
| Sub-builds | Network access attempts | Guix isolation blocks this |

### Recommendations

1. **Audit `xtask/` directory** - It's build logic, review it
2. **Ensure offline mode** - Pass `--offline` to all cargo invocations
3. **Pin xtask dependencies** - Include in cargo-vet scope

---

## Open Questions

1. **Custom Rust target:** How to provide `riscv32imac-unknown-xous-elf` in Guix?
   - Package custom toolchain?
   - Use `-Z build-std`?

2. **Workspace structure:** Does `cargo-inputs` handle workspace members correctly?

3. **Build artifacts:** What exactly should be installed? `.img`, `.bin`, `.elf`?

4. **Testing:** How to run tests (requires RISC-V emulation)?

---

## Next Steps

1. [ ] Run `extract-git-deps.py` on actual xous-core Cargo.lock
2. [ ] Compute hashes for all git deps
3. [ ] Create `rust-sources.scm` entries
4. [ ] Test `cargo-inputs-from-lockfile` for crates.io deps
5. [ ] Create package definition
6. [ ] Handle custom Rust target
7. [ ] Test build in Guix container
8. [ ] Add cargo-vet auditing

---

## References

- [Guix Blog: A New Rust Packaging Model](https://guix.gnu.org/en/blog/2025/a-new-rust-packaging-model/)
- [guix-rust-registry](https://codeberg.org/guix/guix-rust-registry)
- [Issue #3824: Workflow discussion](https://codeberg.org/guix/guix/issues/3824)
- [cargo-build-system source](https://github.com/ecbrown/guix/blob/master/guix/build/cargo-build-system.scm)
- [cargo xtask convention](https://github.com/matklad/cargo-xtask)
